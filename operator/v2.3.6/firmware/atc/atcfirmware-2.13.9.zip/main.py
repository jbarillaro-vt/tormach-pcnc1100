##############################################################################
# main.py
#
# ATCNG board initialization and application launch
#
# Copyright (c) 2016 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file board and application initialization and launches the main app
##############################################################################

# Load Modules
import micropython
import settings
import io
import stepper
import carousel
import comms

# Emergency exception buffer
micropython.alloc_emergency_exception_buf(100)

# optimize the byte codes - slower startup
micropython.opt_level(8)

# Startup glamor
io.LEDglamor()

# Start the LED Heartbeat
io.LEDheartbeat()

# Start the Input debouncer
io.debouncer()

# Start the stepper subsystem
stepper.init()

# Launch the program loop, loops forever on uart input
# interrupt with ^c on REPL
comms.commandLoop()
