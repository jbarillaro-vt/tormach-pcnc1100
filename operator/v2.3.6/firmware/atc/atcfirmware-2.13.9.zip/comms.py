##############################################################################
# comms.py
#
# ATCNG host communications
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains host communications and host command execution.
##############################################################################

#imports
import pyb
import gc
import settings
import stepper
import io
import os
import carousel
import zloader
import machine
import version

# error handling
errors = 0                  # consolidated errors variable
errHoming = 1               # and bit-masked flags
errPressure = 2
errDrawBarConflict = 4
errSpindleConflict = 8

def consolidateErrors():
    global errors
    errors = 0
    if carousel.homed == 0:
        errors |= errHoming
    if io.pressure == 0:
        errors |= errPressure
    if io.vfd != 0:
        errors |= errSpindleConflict

# setup UART
uart = pyb.UART(settings.UART, settings.BAUD)

def help():
    uprint("Online help has been deprecated\r\n")

def shortVersion():
    out = "Z-Bot Automatic Tool Changer II "+version.firmware
    if 'VL' in settings.machine:
        out += " - VFD: Level"
    out += " - TOOLS: " + repr(settings.TOOLS) + "\r\n"
    uprint(out)

def longVersion():
    out = "Z-Bot Automatic Tool Changer II "+version.firmware+"\r\n"
    out += "PROFILE: " + settings.machine + "\r\n"
    out += "TOOLS: " + repr(settings.TOOLS) + "\r\n"
    out += "MAXSPEED: " + repr(settings.MAXSPEED) + "\r\n"
    out += "MINSPEED: " + repr(settings.MINSPEED) + "\r\n"
    out += "ACCEL: " + repr(settings.ACCEL) + "\r\n"
    out += "DECEL: " + repr(settings.DECEL) + "\r\n"
    out += "CIRCUMFERENCE: " + repr(settings.CIRCUMFERENCE) + "\r\n"
    out += "HOMEOFFSET: " + repr(stepper.HOMEOFFSET) + "\r\n"
    out += "VFD: "
    if 'VL' in settings.machine:
        out += 'Level'
    else:
        out += 'Pulsed'
    out += "\r\n"
    out += "USEFAULT: "
    if settings.USEFAULT:
        out += "YES"
    else:
        out += "NO"
    out += "\r\n"
    out += "Copyright (c) 2016 Z-Bot, LLC\r\n"
    uprint(out)

# Input ######################################################################

def getCommand():
    io.yellow.off()
    command = b' '
    while command[len(command)-1] != 13:
        while not uart.any():
            # pass
            if stepper.HOmodCTR == 0:
                stepper.saveHomeOffset()
        command += uart.read(1)
    command = command.decode().strip()
    io.yellow.on()
    io.red.off()
    return command.upper()

# Output #####################################################################

def uprint(sout):
    uart.write(sout)

def cmdAck(val):
    if val == 0:
        return '.'
    elif val ==1:
        return 'X'
    else:
        return '?'

def plusMinus(val):
    if val:
        return '+'
    else:
        return '-'

def reportTool():
    return 'T'+repr(carousel.curtool)

def reportSol1():
    return '1'+plusMinus(io.sol1.value())

def reportSol2():
    return '2'+plusMinus(io.sol2.value())

def reportBlaster(): # same as reportSol2 but different label
    return 'A'+plusMinus(io.sol2.value())

def reportSol3():
    return '3'+plusMinus(io.sol3.value())

def reportDrawbar(): # same as reportSol3 but different label
    return 'D'+plusMinus(io.sol3.value())

def reportSol4():
    return '4'+plusMinus(io.sol4.value())

def reportHomed():
    return 'H'+plusMinus(carousel.homed)

def reportVFDpulsed():
    return 'V'+plusMinus(io.vfd)

def reportVFDlevel():
    return 'V'+plusMinus(io.vfdOn)

def reportChangerIn():
    return 'C'+plusMinus(io.changerin)

def reportPressure():
    return 'P'+plusMinus(io.pressure)

def reportPendant():
    return 'B'+plusMinus(io.pendant)

def reportRPM():
    rpm = io.vfdRPM
    if rpm < 2: rpm = 0
    return 'R'+repr(rpm)

def reportPSI():
    return 'Q'+'{0:.1f}'.format(io.readPressure())

def reportErrors():
    global errors, errHoming, errPressure, errDrawBarConflict, errSpindleConflict

    consolidateErrors()
    out = ''
    if stepper.errors:
        out += ', CAROUSEL ERROR'
    if errors & errHoming:
        out += ', NOT HOMED'
    if errors & errPressure:
        out += ', PRESSURE ERROR'
    if errors & errSpindleConflict:
        out += ', SPINDLE ON'
    return out

def status():
    out = reportTool()+', '
    out += reportHomed()+', '
    out += reportDrawbar()+', '
    out += reportChangerIn()+', '
    out += reportPressure()+', '
    out += reportBlaster()+', '
    if settings.VFDPULSED == 1:
        out += reportVFDpulsed()+', '
    else:
        out += reportVFDlevel()+', '
    out += reportPendant()+', '
    out += reportSol1()+', '
#    out += reportSol2()+', ' # same as air blaster
#    out += reportSol3()+', ' # same as drawbar
    out += reportSol4()+', '
    out += reportPSI()+', '
    out += reportRPM()
    out += '\r\n'
    uprint(out)

# Select Profile ############################################################

profiles = [
        '8-TOOL-VP',
        '8-TOOL-VL',
        '10-TOOL-VP',
        '10-TOOL-VL',
        '12-TOOL-VP',
        '12-TOOL-VL',
        '16-TOOL-VP',
        '16-TOOL-VL',
        '10-TOOL-VP-BT30',
        '10-TOOL-VL-BT30',
        '12-TOOL-VP-BT30',
        '12-TOOL-VL-BT30',
        '16-TOOL-VP-BT30',
        '16-TOOL-VL-BT30'
        ]

def updateProfile(s):
    if s == settings.machine:
        return(True)
    if s in profiles:
        f = open('machine.atc','w')
        f.write("machine = '"+s+"'\n")
        f.close()
        os.sync()
        execStatus(True)
        pyb.delay(6000)
        machine.reset()
    else:
        execStatus(False)

def setTools8p():
    updateProfile('8-TOOL-VP')

def setTools10p():
    updateProfile('10-TOOL-VP')

def setTools12p():
    updateProfile('12-TOOL-VP')

def setTools16p():
    updateProfile('16-TOOL-VP')

def setTools8l():
    updateProfile('8-TOOL-VL')

def setTools10l():
    updateProfile('10-TOOL-VL')

def setTools12l():
    updateProfile('12-TOOL-VL')

def setTools16l():
    updateProfile('16-TOOL-VL')

def setTools10pbt30():
    updateProfile('10-TOOL-VP-BT30')

def setTools12pbt30():
    updateProfile('12-TOOL-VP-BT30')

def setTools16pbt30():
    updateProfile('16-TOOL-VP-BT30')

def setTools10lbt30():
    updateProfile('10-TOOL-VL-BT30')

def setTools12lbt30():
    updateProfile('12-TOOL-VL-BT30')

def setTools16lbt30():
    updateProfile('16-TOOL-VL-BT30')

# test ######################################################################

def tdel():
    pyb.delay(500)

def testSolOnce():
    io.sol1.high()
    tdel()
    io.sol1.low()
    tdel()
    io.sol2.high()
    tdel()
    io.sol2.low()
    tdel()
    io.sol3.high()
    tdel()
    io.sol3.low()
    tdel()
    if uart.any(): return
    io.sol1.high()
    tdel()
    io.sol2.high()
    tdel()
    io.sol3.high()
    tdel()
    io.sol2.low()
    tdel()
    io.sol3.low()
    tdel()
    io.sol1.low()
    tdel()
    if uart.any(): return

def testCircumOnce():
    carousel.tool0()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool8()
    if uart.any(): return

def testCarouselOnce():
    carousel.tool0()
    if uart.any(): return
    carousel.tool1()
    if uart.any(): return
    carousel.tool2()
    if uart.any(): return
    carousel.tool3()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool5()
    if uart.any(): return
    carousel.tool6()
    if uart.any(): return
    carousel.tool7()
    if uart.any(): return
    carousel.home()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool7()
    if uart.any(): return
    carousel.tool3()
    if uart.any(): return
    carousel.tool5()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool0()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool0()
    if uart.any(): return
    carousel.tool4()
    if uart.any(): return
    carousel.tool0()
    if uart.any(): return

def testAllOnce():
    testSolOnce()
    if uart.any(): return
    testCarouselOnce()
    if uart.any(): return

def testSol():
    count = 0
    uart.write('Testing solenoids\r\n')
    while not uart.any():
        if gc.mem_free() < 10000: gc.collect()
        testSolOnce()
        count += 1
        uart.write('Iteration ' + str(count) + '\r\n')
        if uart.any(): return

def testCarousel():
    uart.write('Testing carousel\r\n')
    count = 0
    carousel.findhome()
    while not uart.any():
        if gc.mem_free() < 10000: gc.collect()
        testCarouselOnce()
        count += 1
        uart.write('Iteration ' + str(count) + '\r\n')
        if uart.any(): return

def testCircum():
    uart.write('Testing circumference\r\n')
    count = 0
    carousel.findhome()
    while not uart.any():
        if gc.mem_free() < 10000: gc.collect()
        testCircumOnce()
        count += 1
        uart.write('Iteration ' + str(count) + '\r\n')
        if uart.any(): return

def testAll():
    uart.write('Testing solenoids and carousel\r\n')
    count = 0
    while not uart.any():
        if gc.mem_free() < 10000: gc.collect()
        testAllOnce()
        count += 1
        uart.write('Iteration ' + str(count) + '\r\n')
        if uart.any(): return

def testList():
    uart.write('TESTS\r\n')
    uart.write('TESTSOL: test solenoids\r\n')
    uart.write('TESTCAR: test carousel\r\n')
    uart.write('TESTALL: test solenoids and carousel\r\n')
    uart.write('hit any key to abort a test\r\n')

# Command Dictionary #########################################################

# The command dictionary is a simple key/tuple stucture. The tuple is a
# function:parameter pair. This structure takes the place of a large switch/case
# and other input processing operations.
#
#   Tuple
#   'tool 1': [genericSelectToolFunc,1]
#   'help': [help]
#
#   genericToolFunc(1)      will be executed
#   help()                  will be executed

commands = {
        'TESTALL':testAll,
        'TEST':testList,
        'TESTSOL':testSol,
        'TESTCAR':testCarousel,
        'TESTCIR':testCircum,
        'help':help,
        'HE':help,
        'VE':shortVersion,
        'VL':longVersion,
        'T0':carousel.tool0,
        'T1':carousel.tool1,
        'T2':carousel.tool2,
        'T3':carousel.tool3,
        'T4':carousel.tool4,
        'T5':carousel.tool5,
        'T6':carousel.tool6,
        'T7':carousel.tool7,
        'T8':carousel.tool8,
        'T9':carousel.tool9,
        'T10':carousel.tool10,
        'T11':carousel.tool11,
        'T12':carousel.tool12,
        'T13':carousel.tool13,
        'T14':carousel.tool14,
        'T15':carousel.tool15,
        'T16':carousel.tool16,
        'T17':carousel.tool17,
        'T18':carousel.tool18,
        'T19':carousel.tool19,
        'HO':carousel.home,
        'FH':carousel.findhome,
        'H+':carousel.adjustHomePlus,
        'H-':carousel.adjustHomeMinus,
        '1+':io.sol1.high,
        '1-':io.sol1.low,
        '2+':io.sol2.high,
        '2-':io.sol2.low,
        '3+':io.sol3.high,
        '3-':io.sol3.low,
        '4+':io.sol4.high,
        '4-':io.sol4.low,
        'D+':io.dbDown,
        'D-':io.dbUp,
        'ST':status,
        'ZLOADER':zloader.zloader,
        'STMBOOTLOADER':machine.bootloader,
        'RESET':machine.reset,
        '8-TOOL-VP':setTools8p,
        '10-TOOL-VP':setTools10p,
        '12-TOOL-VP':setTools12p,
        '16-TOOL-VP':setTools16p,
        '8-TOOL-VL':setTools8l,
        '10-TOOL-VL':setTools10l,
        '12-TOOL-VL':setTools12l,
        '16-TOOL-VL':setTools16l,
        '10-TOOL-VP-BT30':setTools10pbt30,
        '12-TOOL-VP-BT30':setTools12pbt30,
        '16-TOOL-VP-BT30':setTools16pbt30,
        '10-TOOL-VL-BT30':setTools10lbt30,
        '12-TOOL-VL-BT30':setTools12lbt30,
        '16-TOOL-VL-BT30':setTools16lbt30
        }

def execStatus(val):
    if val:
        uprint('.\r\n')
    else:
        uprint('X\r\n')
        io.red.on()

#execcommand
def execCommand(command):
    if command == "":
        return
    if command in commands:
        result = commands[command]()
        if repr(type(result)) == "<class 'NoneType'>":
            result = True
        if command == 'ST': return # no result printed - primitive but effective exception hack
        if command == 'VE': return # no result printed - primitive but effective exception hack
        if command == 'VL': return # no result printed - primitive but effective exception hack
        if command == 'ZLOADER':
            return
        execStatus(result)
    else:
        uprint('?\r\n')
        io.red.on()

def commandLoop():
    while 1:
        execCommand(getCommand())
        if gc.mem_free() < 10000:
            gc.collect()


