##############################################################################
# version.py
#
# ATCNG version information
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains version information and functions.
##############################################################################

# major.minor.bugfix <--> api.features.bugfix
firmware = '2.13.9'

