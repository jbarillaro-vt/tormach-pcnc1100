##############################################################################
# io.py
#
# ATCNG IO drivers
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains the bit-wise input and output drivers.
##############################################################################

#imports
import pyb

# LEDs #######################################################################

red = pyb.LED(1)
green = pyb.LED(2)
yellow = pyb.LED(3)

def LEDglamor():
    red.on()
    pyb.delay(200)
    yellow.on()
    pyb.delay(200)
    green.on()
    pyb.delay(200)
    red.off()
    pyb.delay(200)
    yellow.off()

def LEDheartbeat():
    ledtimer = pyb.Timer(10)
    ledtimer.init(freq=4)
    ledtimer.callback(lambda t:green.toggle())

# Solenoids and User Switch ##################################################

sol1 = pyb.Pin(pyb.Pin.cpu.B14,pyb.Pin.OUT)
sol2 = pyb.Pin(pyb.Pin.cpu.C4,pyb.Pin.OUT)
sol3 = pyb.Pin(pyb.Pin.cpu.C5,pyb.Pin.OUT)
sol4 = pyb.Pin(pyb.Pin.cpu.B8,pyb.Pin.OUT)
usrsw = pyb.Switch()

# Draw Bar Interlock #########################################################

dbEnable = False

#def dbDown():
#    global dbEnable
#    if dbEnable:
#        sol3.high()
#        return True
#    else:
#        return False
#
#def dbUp():
#    global dbEnable
#    if dbEnable:
#        sol3.low()
#        return True
#    else:
#        return False
def dbDown():
    sol3.high()
    return True

def dbUp():
    sol3.low()
    return True

# Raw inputs #################################################################

# Sensors - with pullups
pressureRaw = pyb.Pin(pyb.Pin.cpu.B0,pyb.Pin.IN)
pressureRaw.init(pyb.Pin.IN,pull=pyb.Pin.PULL_UP)
indexRaw = pyb.Pin(pyb.Pin.cpu.B1,pyb.Pin.IN)
indexRaw.init(pyb.Pin.IN,pull=pyb.Pin.PULL_UP)
pendantRaw = pyb.Pin(pyb.Pin.cpu.B12,pyb.Pin.IN)
pendantRaw.init(pyb.Pin.IN,pull=pyb.Pin.PULL_UP)
pedalRaw = pyb.Pin(pyb.Pin.cpu.B15,pyb.Pin.IN)
pedalRaw.init(pyb.Pin.IN,pull=pyb.Pin.PULL_UP)
vfdOnRaw = pyb.Pin(pyb.Pin.cpu.C12,pyb.Pin.IN)

# Sensors - no pullups
changerinRaw = pyb.Pin(pyb.Pin.cpu.B13,pyb.Pin.IN)

# Debounced inputs ###########################################################

# Uses timer 12

pressureDB = 0
pendantDB = 0
pedalDB = 0
vfdDB = 0
vfd = 0         # pulsed VFD speed input - new VFDs
vfdmicros = 0
vfdmicrosq = 0
vfdRPM = 0
vfdOn = 0       # static VFD running input - pre series 4 VFDs
pressure = 0
pendant = 0
pendantq = 0    #registered version of pendant - for edge detection
pedal = 0
pedalq = 0      #registered version of pedal - for edge detection
changerin = 0
index = 0

def debounceInputs():
    global changerin, index
    global pressureDB, pendantDB, pedalDB, vfdDB, vfd
    global pressure, pendant, pendantq, pedal, pedalq
    global vfdRPM, dbEnable
    global vfdOn

    # undebounced, but inverted inputs
    if indexRaw.value() == 0:
        index = 1
    else:
        index = 0
    if changerinRaw.value() == 0:
        changerin = 1
    else:
        changerin = 0
    # pressure
    if pressureRaw.value() == 0:
        pressureDB += 1
    else:
        pressureDB = 0
        pressure = 0
    if pressureDB == 25:
        pressureDB = 24
        pressure = 1
    # pendant
    if pendantRaw.value() == 0:
        pendantDB += 1
    else:
        pendantDB = 0
        pendant = 0
    if pendantDB == 25:
        pendantDB = 24
        pendant = 1
    # pedal
    if pedalRaw.value() == 0:
        pedalDB += 1
    else:
        pedalDB = 0
        pedal = 0
    if pedalDB == 25:
        pedalDB = 24
        pedal = 1
    # handle the drawbar from the pendant
    if (vfd == 0) and (pendant != pendantq):
        if pendant and dbEnable:
            sol3.high()
            sol4.high()
        else:
            sol3.low()
            sol4.high()
        pendantq = pendant
    # handle the drawbar from the pedal
    if (vfd == 0) and (pedal != pedalq):
        if pedal and dbEnable:
            sol3.high()
            sol4.high()
        else:
            sol3.low()
            sol4.high()
        pedalq = pedal
    # vfd
    if vfdDB < 1000:
        vfdDB += 1
        dbEnable = False
    else:
        vfd = 0
        vfdRPM = 0
    if vfd == 0 and pendant == 0:
        dbEnable = True
    vfdOn = not vfdOnRaw.value()


def debouncer():
    dbtimer = pyb.Timer(12, freq=1000)
    dbtimer.callback(lambda t:debounceInputs())

# VFD interrupt
def vfdInt(line):
    global vfdDB, vfd, vfdRPM
    global vfdmicros, vfdmicrosq
    vfdmicros = pyb.micros()
    vfdRPM = 30000000//pyb.elapsed_micros(vfdmicrosq)
    vfdmicrosq = vfdmicros
    vfd = 1
    vfdDB = 0

extVFDint = pyb.ExtInt(pyb.Pin.cpu.C12, pyb.ExtInt.IRQ_FALLING, pyb.Pin.PULL_NONE, vfdInt)


# Pressure ADC
pressADC = pyb.ADC(pyb.Pin.cpu.C3)
adcK = 0.039711

def readPressure():
    pVal = 0
    i = 16
    while i > 0:
        pVal += pressADC.read()
        i -= 1
    return (pVal>>4)*adcK
    

