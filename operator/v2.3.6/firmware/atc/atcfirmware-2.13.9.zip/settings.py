##############################################################################
# settings.py
#
# ATCNG configuration and settings
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains UART settings, machine type selections, number of tools,
# offsets and other settings.
##############################################################################

# settings.py
# machine type, options and operational settings

# Machine type
machfile = open('machine.atc','r')
exec(machfile.read())   # creates or modifies variable machine
machfile.close()

# Host UART settings
UART = 6
BAUD = 57600
STOP = 1
PARITY = None

# Motor gear ratio
# Gear #1 teeth: 33
# Gear #2 teeth: 19
# Gear #3 teeth: 16
# Gear #4 teeth: 30
# Total gear ratio: 198/19
# Total steps per revolution:
#  1600 * 198 / 19
#  16673.684210526317

# Carousel settings
# SPEED: steps per second
# ACCEL and STEPDECEL: steps per second per second
# ADJSTEP should be approx 0.5 degrees (circumference / 720)

TOOLS = 0
CIRCUMFERENCE = 0
ADJSTEPS = 0
MINSPEED = 0
MAXSPEED = 0
ACCEL = 0
DECEL = 0
VFDPULSED = 0
USEFAULT = 0

def reload():
    global machine, TOOLS, CIRCUMFERENCE, ADJSTEPS, MINSPEED, MAXSPEED
    global ACCEL, DECEL, VFDPULSED
    machfile = open('machine.atc','r')
    exec(machfile.read())   # creates or modifies variable machine
    machfile.close()
    if machine == '8-TOOL-VP': # optimized for 440
        TOOLS = 8
        CIRCUMFERENCE = 8000
        ADJSTEPS = 8
        MINSPEED = 125
        MAXSPEED = 6000
        ACCEL = 30
        DECEL = 30
        VFDPULSED = 1
    elif machine == '8-TOOL-VL': # optimized for 440
        TOOLS = 8
        CIRCUMFERENCE = 8000
        ADJSTEPS = 8
        MINSPEED = 125
        MAXSPEED = 6000
        ACCEL = 30
        DECEL = 30
        VFDPULSED = 0
    elif machine == '10-TOOL-VP': # optimized for 770
        TOOLS = 10
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 1
    elif machine == '10-TOOL-VL': # optimized for 770
        TOOLS = 10
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 0
    elif machine == '12-TOOL-VP': # optimized for 1100
        TOOLS = 12
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 1
    elif machine == '12-TOOL-VL': # optimized for 1100
        TOOLS = 12
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 0
    elif machine == '16-TOOL-VP': # not yet optimized
        TOOLS = 16
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 1
    elif machine == '16-TOOL-VL': # not yet optimized
        TOOLS = 16
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 22
        MINSPEED = 200
        MAXSPEED = 9000
        ACCEL = 20
        DECEL = 20
        VFDPULSED = 0
    elif machine == '10-TOOL-VP-BT30': # not yet optimized for 770 BT30
        TOOLS = 10
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 1
    elif machine == '10-TOOL-VL-BT30': # not yet optimized for 770 BT30
        TOOLS = 10
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 0
    elif machine == '12-TOOL-VP-BT30': # not yet optimized for 1100 BT30
        TOOLS = 12
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 1
    elif machine == '12-TOOL-VL-BT30': # not yet optimized for 1100 BT30
        TOOLS = 12
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 0
    elif machine == '16-TOOL-VP-BT30': # not yet optimized
        TOOLS = 16
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 1
    elif machine == '16-TOOL-VL-BT30': # not yet optimized
        TOOLS = 16
        CIRCUMFERENCE = 16673.684210526317
        ADJSTEPS = 6
        MINSPEED = 200
        MAXSPEED = 7000
        ACCEL = 15
        DECEL = 15
        VFDPULSED = 0
    else:
        TOOLS = 8
        CIRCUMFERENCE = 8000
        ADJSTEPS = 8
        MINSPEED = 125
        MAXSPEED = 6000
        ACCEL = 30
        DECEL = 30
        VFDPULSED = 0

reload()
