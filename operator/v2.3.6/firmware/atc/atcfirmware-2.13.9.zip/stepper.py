##############################################################################
# stepper.py
#
# ATCNG spindle stepper motor driver
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains functions related to the stepper motor.
#
# This is a new implementation. The new structure replaces the interrupt driven
# method with a polled-mode implementation.
# It only knows about a linear distance starting from 0 to the target endpoint.
# It only needs to be concerned with the acceleration slope which starts at 0,
# the deceleration slope and its starting point and the end point.
# It is set up so that all error checking can be performed outside of the
# interrupt routine. The public position variable is only valid between
# operations.
#
##############################################################################

import micropython
import stm
import pyb
import settings
import io
import os

# Constants and Variables ####################################################

# contants
TCLK = 1000000                      # timebase for steptimer
ErrFault = 1                        # motor controller fault - can be ORed
ErrHoming = 2                       # homing error - can be ORed
ErrPosition = 4                     # position error - can be ORed
ErrStepping = 8                     # interrupt latency error - can be ORed

# setting variables
minspeed = settings.MINSPEED        # minimum speed
maxspeed = settings.MAXSPEED        # maximum speed
circum = int(settings.CIRCUMFERENCE) # circumference in int steps
circumfrac = settings.CIRCUMFERENCE - circum # fractional portion
adjsteps = settings.ADJSTEPS        # number of steps for adjusting HOME
accel = settings.ACCEL              # acceleration rate
decel = settings.DECEL              # deceleration rate
HOMEOFFSET = 0
HOmodCTR = -1                       # modified home offset value count down counter
                                    # >0 count down, 0 wait for hofile write, <0 stop

# home offset setting - and weirdness to work around interrupt service routine limitations

homefile = open('offset.atc','r')
exec(homefile.read())   # creates or modifies variable HOMEOFFSET
homefile.close()

def saveHomeOffset():
    global HOMEOFFSET, HOmodCTR
    homefile = open('offset.atc','w')
    out = 'HOMEOFFSET = ' + repr(HOMEOFFSET) + '\r\n'
    homefile.write(out)
    homefile.close()
    HOmodCTR = -1

def hocountdown():
    global HOmodCTR
    if HOmodCTR >0:
        HOmodCTR -= 1

hotimer = pyb.Timer(11)
hotimer.init(freq=1)
hotimer.callback(lambda t:hocountdown())

# operating variables
position = 0                        # stepper position - not valid during moves
poserror = 0                        # stepper position error
counter = 0                         # step counter for current move
speed = minspeed                    # current speed
xcel = accel                        # current accel/decel rate
decelpos = 0                        # position to start deceleration
targetpos = circum                  # target position
run = 0                             # 1: running/enabled, 0: stopped/disabled
direction = 1                       # 1: CW (P1 -> P2), -1: CCW (P2 -> P1)
errors = 0                          # bit-mapped error codes
homing = 0                          # flag for stepint homing mode
indexA0 = 0                         # stores index negation position - homing
indexA1 = 0                         # stores index negation position - homing
indexA2 = 0                         # stores index negation position - homing
indexN0 = 0                         # stores indes assertion position - homing
indexN1 = 0                         # stores indes assertion position - homing
indexN2 = 0                         # stores indes assertion position - homing
index = 0                           # local fast version of io.index
indexq = 0                          # state of io.index at last step
dummy = 0                           # needed to dump returned values from ASM functions

def dumpVars():                     # debug print
    print('position '+repr(position))
    print('poserror '+repr(poserror))
    print('counter '+repr(counter))
    print('speed '+repr(speed))
    print('xcel '+repr(xcel))
    print('decelpos '+repr(decelpos))
    print('targetpos '+repr(targetpos))
    print('run '+repr(run))
    print('direction '+repr(direction))
    print('errors '+repr(errors))
    print('indexA0 '+repr(indexA0))
    print('indexN0 '+repr(indexN0))
    print('index '+repr(index))
    print('indexq '+repr(indexq))
    print('dummy '+repr(dummy))
    print('\r\n')

# IO signals #################################################################

STEP = pyb.Pin(pyb.Pin.cpu.A0,pyb.Pin.OUT)      # high-true step output
DIR = pyb.Pin(pyb.Pin.cpu.A2,pyb.Pin.OUT)       # 0: CW, 1: CCW

# settings ###################################################################

def reload():
    global minspeed, maxspeed, circum, accel, decel, adjsteps
    minspeed = settings.MINSPEED        # minimum speed
    maxspeed = settings.MAXSPEED        # maximum speed
    circum = settings.CIRCUMFERENCE     # circumference for wrap-around limits
    accel = settings.ACCEL              # acceleration rate
    decel = settings.DECEL              # deceleration rate
    adjsteps = settings.ADJSTEPS        # number of steps for adjusting HOME

# Assembly Functions #########################################################
# special routines to change the frequency without uPy's special, automatic help

@micropython.asm_thumb
def waitTimerElapsed(r0):               # comparison value
    movwt(r2,stm.TIM5)                  # load timer base address
    label(wtloop)                       # head of the loop
    ldr(r1,[r2,stm.TIM_CNT])            # read the timer counter
    sub(r1,r1,r0)                       # subract for the compare
    blt(wtloop)                         # loop if timer less than comparison value

@micropython.asm_thumb
def polledStep():
    mov(r0,1)                           # step bit set mask for GPIOA.0
    movwt(r3,stm.GPIOA)                 # load the GPIO address
    str(r0,[r3,stm.GPIO_BSRR])          # assert the step signal
    movwt(r0,5)                         # time the step pulse to 4uS
    movwt(r2,stm.TIM5)                  # load timer base address
    mov(r1,0)                           # clear the timer counter
    str(r1,[r2,stm.TIM_CNT])
    label(psloop)                       # head of the loop
    ldr(r1,[r2,stm.TIM_CNT])            # read the timer counter
    sub(r1,r1,r0)                       # subract for the compare
    blt(psloop)                         # loop if timer less than comparison value
    movwt(r0,0x10000)                   # step bit reset mask for GPIOA.0
    str(r0,[r3,stm.GPIO_BSRR])          # negate the step signal

# Speed Control and Postion ##################################################

# step bounding
@micropython.native # viper cannot be used, there is access to objects
def wrapbound(val):         # this one can't be used in ISR
    return val % circum

# Timer and Channel Configuration ############################################
steptimer = pyb.Timer(5, prescaler=83, period=0x3fffffff)

# Initialization for disabling interrupts ####################################
irqstat = pyb.disable_irq()         # create a global irqstat
pyb.enable_irq(irqstat)

# Polled-mode stepper driver #################################################

@micropython.native # viper cannot be used, there is access to objects
def stepHandler():
    global counter, xcel, index, indexq
    global indexA0, indexA1, indexA2
    global indexN0, indexN1, indexN2
    global speed, dummy
    global irqstat, run

    dummy = polledStep()
    dummy = (TCLK//speed)-16            # calculate target counter value
                                        # '16' accounts for the overhead
    speed += xcel                       # adjust the speed
    if speed > maxspeed:                # bound the speed
        speed = maxspeed
        xcel = 0                        # minimizing use of speed bounding
    elif speed < minspeed:
        speed = minspeed

    counter += 1                        # adjust the step counter

    if homing:
        index = io.indexRaw.value()     # read the hall sensor
        # log assertion and negation points of the index sensor
        if not index and indexq:        # assertion
            indexA2 = indexA1
            indexA1 = indexA0
            indexA0 = counter
        if index and not indexq:        # negation
            indexN2 = indexN1
            indexN1 = indexN0
            indexN0 = counter
        indexq = index                  # update last index variable

    if counter == decelpos:             # check for deceleration start point
        xcel = -decel
    if counter == targetpos:            # check for stop point
        run = 0                         # stop if so
    dummy = waitTimerElapsed(dummy)     # wait for the timer to elapse

# Main Stop and Start Functions ##############################################

def stop():
    global run
    run = 0

# set move parameters based on target position and start moving
def start(newpos):
    global targetpos, direction, decelpos, xcel, accel
    global speed, minspeed
    global counter, run
    if position != newpos:              # run only if different positions
        # setup counters and limits
        xcel = accel
        counter = 0                     # set the 'runaway' limit
        speed = minspeed                # set the starting speed
        targetpos = abs(newpos-position) # set the target position
        print('  position',repr(position))
        print('  poserror',repr(poserror))
        print('  newpos',repr(newpos))
        print('  targetpos',repr(targetpos))
        print('\r\n')
        accelsteps = int((maxspeed - minspeed)//accel)
        decelsteps = int((maxspeed - minspeed)//decel)
        if targetpos > (accelsteps + decelsteps):
            decelpos = targetpos - decelsteps
        else:
            decelpos = targetpos>>1
        if newpos > position:           # set the initial direction,
            direction = 1               # CW for away from 0
            DIR.low()
        else:
            direction = -1               # CCW for towards 0
            DIR.high()
        pyb.delay(50)                   # allow 50ms for everything to stablilize
        run = 1                         # driver to run mode

# general movement functions

def move(newpos):
    global minspeed, position, poserror, circum, irqstat
    global  errors, ErrPosition, ErrFault, ErrStepping
    errors = 0                          # clear the error register
    maxtimer = TCLK//(minspeed+1)       # calculate max counter value plus a little
    # adjust newpos to account for fractional error using adjpos
    adjpos = newpos
    if int(poserror):                   # check for an error of or step or larger
        adjpos += int(poserror)         # add in the integer portion of the error
        poserror = poserror - int(poserror) # save only the decimal portion of the error
    # end of adjust
    start(adjpos)                       # start the movement
    irqstat = pyb.disable_irq()         # must disable interrupts to allow this code to complete
    while(run):                         # loop until stopped
        stepHandler()                   # make steps
    pyb.enable_irq(irqstat)             # re-enable interrupts
    position = wrapbound(newpos)
    return not errors

def optimalmove(newpos):
    global position, circum, poserror
    # optimize move
    if abs(newpos-position)>(circum>>1):
        if newpos > position:
            newpos = newpos - circum
            poserror -= circumfrac
        else:
            newpos = newpos + circum
            poserror += circumfrac
    move(newpos)

def adjCircle(a,b):                      # wrap the numbers around the circumference
    half = circum >> 1
    if abs(a - b) > half:
        if a < b:
            a += circum
        else:
            b += circum
    return a,b

def calcIndex():
    global indexA0, indexA1, indexA2
    global indexN0, indexN1, indexN2

    half = circum >> 1

    divisor = 1

    # fail if either of the first samples has not been taken
    if indexA0 == -1 or indexN0 == -1: return False

    # data substitution: handle potentially missing samples
    if abs(indexA1) == 1:       # if missing, substitute first sample
        indexA1 = indexA0
    else:
        indexA0,indexA1 = adjCircle(indexA0,indexA1)

    if abs(indexA2) == 1:       # if missing, substitute and average of the first sample
        indexA2 = (indexA0 + indexA1) // 2
    else:
        indexA0,indexA2 = adjCircle(indexA0,indexA2)

    # average the normalized positions
    avgA = (indexA0 + indexA1 + indexA2) // 3

    # data substitution: handle potentially missing samples
    if abs(indexN1) == 1:       # if missing, substitute first sample
        indexN1 = indexN0
    else:
        indexN0,indexN1 = adjCircle(indexN0,indexN1)

    if abs(indexN2) == 1:       # if missing, substitute and average of the first sample
        indexN2 = (indexN0 + indexN1) // 2
    else:
        indexN0,indexN2 = adjCircle(indexN0,indexN2)

    # average the normalized positions
    avgN = (indexN0 + indexN1 + indexN2) // 3

    # normalize assertion and negation average positions in the same way
    diff = avgA - avgN
    if abs(diff) > half:
        if avgA < avgN:
            avgA += circum
        else:
            avgN += circum

    # return the average all 6 points
    return (avgA + avgN) // 2

def findhome():
    global circum, position, HOMEOFFSET, maxspeed, homing
    global indexA0, indexA1, indexA2
    global indexN0, indexN1, indexN2
    speedSave = maxspeed
    maxspeed = maxspeed//2      # go at half speed for homing
    position = 0
    indexA0 = -1
    indexA1 = -1
    indexA2 = -1
    indexN0 = -1 
    indexN1 = -1 
    indexN2 = -1 
    homing = 1
    move(circum-1)
    maxspeed = speedSave 
    position -= HOMEOFFSET
    print('indexA0= '+repr(indexA0))
    print('indexA1= '+repr(indexA1))
    print('indexA2= '+repr(indexA2))
    print('indexN0= '+repr(indexN0))
    print('indexN1= '+repr(indexN1))
    print('indexN2= '+repr(indexN2))
    avg = calcIndex()
    print('avg= '+repr(avg))
    homing = 0
    optimalmove(avg)
    print('...')
    print('indexA0= '+repr(indexA0))
    print('indexA1= '+repr(indexA1))
    print('indexA2= '+repr(indexA2))
    print('indexN0= '+repr(indexN0))
    print('indexN1= '+repr(indexN1))
    print('indexN2= '+repr(indexN2))
    print('sensor= '+repr(io.indexRaw.value()))
    print('target= '+repr((indexA0+indexN0)>>1))
    print('sum= '+repr(indexA0+indexN0))
    position = 0
    homing = 0
    return not (
            indexA0 == -1 or 
            indexA1 == -1 or 
            indexA2 == -1 or 
            indexN0 == -1 or 
            indexN1 == -1 or 
            indexN2 == -1
            )

def adjustPosition(val):
    global position, HOMEOFFSET, HOmodCTR
    # val is in steps
    x = position
    position -= val
    HOMEOFFSET += val
    HOmodCTR = 5
    move(x)

def measureCircumference():
    global maxspeed, circum, position
    circum = settings.CIRCUMFERENCE
    findhome()
    circum = 100000
    maxspeed = 3000
    indexA0q = indexA0
    indexN0q = indexN0
    position = 0
    start(circum)
    while 1:
        if run == 0:
            return
        if indexA0q != indexA0:
            print('indexA0='+repr(indexA0-indexA0q))
            indexA0q = indexA0
        if indexN0q != indexN0:
            print('indexN0='+repr(indexN0-indexN0q))
            indexN0q = indexN0

def init():
    global indexq, dummy
    indexq = io.indexRaw.value()
