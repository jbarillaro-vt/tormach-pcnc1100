##############################################################################
# carousel.py
#
# ATCNG tool carousel operation
#
# Copyright (c) 2018 Z-Bot, LLC
# All Rights Reserved
# Author: Noel Henson
#
# This file contains functions for tool selection and other carousel operations
##############################################################################

#imports
import pyb
import settings
import io
import stepper

# settings
tools = settings.TOOLS
steps = settings.CIRCUMFERENCE

# variables
curtool = 0
homed = 0

# tool positions and selection
toolpos = []
for i in range(tools):
    toolpos.append(int(i*steps/tools))

def selectTool(tool):

    global  toolpos, curtool, tools
    if tool >= tools or not homed:
        return False
    stepper.optimalmove(toolpos[tool])
    curtool = tool
    return True
    #put error check here

# tool shortcuts to keep the comms' command dictionary simple for this version

def tool0():
    return selectTool(0)

def tool1():
    return selectTool(1)

def tool2():
    return selectTool(2)

def tool3():
    return selectTool(3)

def tool4():
    return selectTool(4)

def tool5():
    return selectTool(5)

def tool6():
    return selectTool(6)

def tool7():
    return selectTool(7)

def tool8():
    return selectTool(8)

def tool9():
    return selectTool(9)

def tool10():
    return selectTool(10)

def tool11():
    return selectTool(11)

def tool12():
    return selectTool(12)

def tool13():
    return selectTool(13)

def tool14():
    return selectTool(14)

def tool15():
    return selectTool(15)

def tool16():
    return selectTool(16)

def tool17():
    return selectTool(17)

def tool18():
    return selectTool(18)

def tool19():
    return selectTool(19)

def home():
    global homed
    if not homed:
        if stepper.findhome():
            homed = True
        else: return False
    selectTool(0)

def findhome():
    global homed
    homed = False
    return home()

def adjustHomePlus():
    if homed:
        stepper.adjustPosition(stepper.adjsteps)
        return True
    else:
        return False

def adjustHomeMinus():
    if homed:
        stepper.adjustPosition(-stepper.adjsteps)
        return True
    else:
        return False
